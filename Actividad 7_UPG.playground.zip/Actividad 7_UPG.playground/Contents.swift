/*--------------------------------------- Ejercicio 1 ----------------------------------------*/
import Foundation
/*Ejercicio 1 Ulises 2888460 */
var costo_referencia:[Float] = [8.3,10.5,9.9]

func impuesto (arreglo: [Float]) -> [Float]{
    var resultado : [Float] = []
    for i in arreglo {
        resultado.append(i * 0.16)
    }
    return resultado
}


print (impuesto (arreglo:costo_referencia))

/*---------------------------------------- Ejercicio 2 -----------------------------------*/
/*Ejercicio 2 Ulises 2888460*/

let suma = {(x:Int, y:Int) -> Int in return x + y }

suma(2,2)

print (suma (2,2))


func sumaTres ( a:Int , b:Int, c:Int ) -> Int {
    return suma (a,b) + c
}
sumaTres (a:2 ,b:2 ,c:2)

print (sumaTres (a:2 ,b:2 ,c:2))



/*---------------------------------------- Ejercicio 3 ----------------------------------------*/

/*Ejercicio 3 Ulises 2888460*/

func cambioInt (a:Int, b:Int) -> (Int,Int){
    var temp = a
    var a = a
    var b = b
    a = b
    b = temp
    return (a,b)
}

print(cambioInt(a:2, b:4))


/*---------------------------------------- Ejercicio 4 ----------------------------------------*/

/*Ejercicio 4  Ulises 2888460*/

var datos = [3,7,9,2]

func transformar (datos:[Int]) -> [Int]{
    return datos
}

func transforme  (datos:[Int]) -> [Int]{
    
    var nuevo : [Int] = []
    for i in datos{
        nuevo.append (i * 2)
    }
    return nuevo
}

print (transforme(datos:datos))





/*---------------------------------------- Ejercicio 5 ----------------------------------------*/


/*Ejercicio 5  Ulises 2888460*/

var precios = [4.2, 5.3, 8.2, 4.5]

var mape = precios.map {a in return a * 0.16}


print (mape)

/*---------------------------------------- Ejercicio 6 ----------------------------------------*/


/*Ejercicio 6  Ulises 2888460*/



var impuesto = precios.map {a in return a * 0.84}


print (impuesto)

var precio_menor = impuesto.filter {a in a > 6}

print (precio_menor)
